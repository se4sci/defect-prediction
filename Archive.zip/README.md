# Defect Prediction
## Scientific Computation Software
[![Build Status](https://travis-ci.org/ai-se/se4sci.svg?branch=master)](https://travis-ci.org/ai-se/se4sci)
[![Coverage Status](https://coveralls.io/repos/github/se4sci/defect-prediction/badge.svg?branch=master)](https://coveralls.io/github/se4sci/defect-prediction?branch=master)![Python Version](https://img.shields.io/badge/python-3.6-blue.svg)
![AUR](https://img.shields.io/aur/license/yaourt.svg)
